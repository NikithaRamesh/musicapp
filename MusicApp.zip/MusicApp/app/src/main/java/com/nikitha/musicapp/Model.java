package com.nikitha.musicapp;

public class Model {

    String name;
    String mbid;
    String url;
    String image;
    String playcount;
    String listeners;


    Model(String image,String name,String mbid,String url)
    {
        this.image=image;
        this.name=name;
        this.mbid=mbid;
        this.url=url;
    }

    Model(String image,String name,String mbid,String url,String playcount,String listeners)
    {
        this.image=image;
        this.name=name;
        this.mbid=mbid;
        this.url=url;
        this.playcount=playcount;
        this.listeners=listeners;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPlaycount() {
        return playcount;
    }

    public void setPlaycount(String playcount) {
        this.playcount = playcount;
    }

    public String getListeners() {
        return listeners;
    }

    public void setListeners(String listeners) {
        this.listeners = listeners;
    }
}
