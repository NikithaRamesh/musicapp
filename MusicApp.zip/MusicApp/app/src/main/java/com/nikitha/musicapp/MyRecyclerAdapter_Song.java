package com.nikitha.musicapp;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by 2303043r on 27/08/2018.
 */

 //Adapter to display artist and album details
public class MyRecyclerAdapter_Song extends RecyclerView.Adapter<MyRecyclerAdapter_Song.MyViewHolder> {
    private List<Model> artist_details;
    private Context context;
    private LayoutInflater inflater;

    public MyRecyclerAdapter_Song(Context context, List<Model> artist_details) {

        this.context = context;
        this.artist_details = artist_details;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View rootView = inflater.inflate(R.layout.search_artist_item, parent, false);
        return new MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final Model model = artist_details.get(position);

        //Pass the values of feeds object to Views
        holder.name.setText(model.getName());

        //Check if URL is empty - If empty load the launcher icon else load the url image
        if(model.getImage().isEmpty()) {
            Picasso.with(context).load(R.mipmap.ic_launcher_round).into(holder.image);
        }
        else
        {
            Picasso.with(context).load(model.getImage()).into(holder.image);

        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog alertDialog = new AlertDialog.Builder(context).create();

                // Set Custom Title
                TextView title = new TextView(context);
                // Title Properties
                title.setText(model.getName());
                title.setPadding(10, 10, 10, 10);   // Set Position
                title.setGravity(Gravity.CENTER);
                title.setTextColor(Color.BLACK);
                title.setTextSize(20);
                alertDialog.setCustomTitle(title);

                // Set Message
                TextView msg = new TextView(context);

                msg.setText("Playcounts: "+ model.getPlaycount() + "\n"+"\n"+ "Listeners: "+model.getListeners());
                msg.setGravity(Gravity.CENTER_HORIZONTAL);
                msg.setTextColor(Color.BLACK);
                msg.setTextSize(16);
                alertDialog.setView(msg);



                new Dialog(context);
                alertDialog.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return artist_details.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView name,mbid,url;
        private ImageView image;

        public MyViewHolder(View itemView) {
            super(itemView);


          name=itemView.findViewById(R.id.artist_name_textView);
          image=itemView.findViewById(R.id.artist_imageView);

        }
    }
}
