package com.nikitha.musicapp;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * This class fetches the artists name and image based on the user's search text
 */
public class Search_Artist extends Fragment {


    RecyclerView recyclerView;
    List<Model> artist_details = new ArrayList<>();
    MyRecyclerAdapter adapter;
    Model model;

    ProgressDialog progressDialog;
    RequestQueue queue;

    EditText search_text;
    Button search_button;
    String name;

    public Search_Artist() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search__artist, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getActivity().setTitle("Artist");

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        recyclerView = view.findViewById(R.id.recyclerview);
        search_text=view.findViewById(R.id.search_editText);
        search_button=view.findViewById(R.id.search_button);

        adapter = new MyRecyclerAdapter(getActivity(), artist_details);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);

        recyclerView.setAdapter(adapter);

        //Getting Instance of Volley Request Queue
        queue = NetworkController.getInstance(getActivity()).getRequestQueue();


        //Button to fetch search results and display
        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Get the search text from the user
                name=search_text.getText().toString();

                //Display ProgressDialog
                progressDialog = new ProgressDialog(getActivity());
                progressDialog.setMessage("Loading");
                progressDialog.show();

                //URL for last.fm's artist.search method
                final String url = "http://ws.audioscrobbler.com/2.0/?method=artist.search&artist="+name+"&api_key=f94979beafcaf8d4d58ddac8cf924d1c&format=json";

                queue = Volley.newRequestQueue(getActivity());
                // Initialize a new JsonObjectRequest instance
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                        Request.Method.GET,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                try{

                                    JSONObject object = response;

                                    JSONObject results_object = object.getJSONObject("results");
                                    JSONObject artistmatches_object = results_object.getJSONObject("artistmatches");
                                    JSONArray artist_array = artistmatches_object.getJSONArray("artist");

                                    //Clear the list before adding new data to avoid repetition
                                    artist_details.clear();

                                    for (int i = 0; i < artist_array.length(); i++) {

                                        //Fetch the artist details
                                        JSONObject artist_arrayJSONObject = artist_array.getJSONObject(i);
                                        String name = artist_arrayJSONObject.getString("name");
                                        String mbid = artist_arrayJSONObject.getString("mbid");
                                        String url = artist_arrayJSONObject.getString("url");
                                        JSONArray image_array= artist_arrayJSONObject.getJSONArray("image");


                                        //Fetch the artist images
                                        for(int j=0;j<image_array.length();j++) {
                                            JSONObject image_object = image_array.getJSONObject(j);
                                            String image = image_object.getString("#text");
                                            String size = image_object.getString("size");

                                            if(size.equals("large")) {
                                                model = new Model(image, name, mbid, url);

                                                artist_details.add(model);
                                                progressDialog.dismiss();

                                            }

                                        }

                                    }
                                } catch (JSONException e) {
                                    System.out.print(e);
                                }
                                finally {
                                    //Notify adapter about data changes
                                    adapter.notifyDataSetChanged();
                                }
                            }
                        },new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error.getMessage());
                    }
                });

                //Add the request to Volley requestqueue
                queue.add(jsonObjectRequest);


            }
        });


        }



    }




